<template>
  <div class="home">
        <h1>Homepage</h1>
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: "home",
  components: {
  }
};
</script>
